(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'java.util.Objects','io.github.warownia1.simplehttpclient.HttpHeaders','java.util.Optional']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImmutableHttpRequest", null, 'io.github.warownia1.simplehttpclient.HttpRequest');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['method'],'O',['uri','java.net.URI','headers','io.github.warownia1.simplehttpclient.HttpHeaders','body','io.github.warownia1.simplehttpclient.HttpRequest.Body','timeout','java.time.Duration']]]

Clazz.newMeth(C$, 'c$$io_github_warownia1_simplehttpclient_impl_SimpleHttpRequestBuilder',  function (builder) {
Clazz.super_(C$, this);
this.method=$I$(1).requireNonNull$O(builder.method);
this.uri=$I$(1).requireNonNull$O(builder.uri);
this.headers=$I$(2,"of$java_util_Map",[builder.headers.map$()]);
this.body=builder.body;
this.timeout=builder.timeout;
}, 1);

Clazz.newMeth(C$, 'method$',  function () {
return this.method;
});

Clazz.newMeth(C$, 'uri$',  function () {
return this.uri;
});

Clazz.newMeth(C$, 'headers$',  function () {
return this.headers;
});

Clazz.newMeth(C$, 'body$',  function () {
return $I$(3).ofNullable$O(this.body);
});

Clazz.newMeth(C$, 'timeout$',  function () {
return $I$(3).ofNullable$O(this.timeout);
});

Clazz.newMeth(C$, 'toString',  function () {
return this.uri.toString() + " " + this.method ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
