(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'java.util.LinkedHashMap','io.github.warownia1.simplehttpclient.HttpHeaders','io.github.warownia1.simplehttpclient.impl.ResponseInfoImpl',['io.github.warownia1.simplehttpclient.HttpClient','.Version'],'io.github.warownia1.simplehttpclient.impl.SimpleHttpResponse','java.util.concurrent.CompletableFuture']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleHttpClient", null, null, 'io.github.warownia1.simplehttpclient.HttpClient');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler',  function (request, handler) {
var conn=request.uri$().toURL$().openConnection$();
if (!request.method$().equals$O("HEAD")) {
conn.setDoInput$Z(true);
}conn.setRequestMethod$S(request.method$());
request.headers$().map$().forEach$java_util_function_BiConsumer(((P$.SimpleHttpClient$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "SimpleHttpClient$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (header, values) {
for (var value, $value = values.iterator$(); $value.hasNext$()&&((value=($value.next$())),1);) {
this.$finals$.conn.addRequestProperty$S$S(header, value);
}
});
})()
), Clazz.new_(P$.SimpleHttpClient$lambda1.$init$,[this, {conn:conn}])));
if (request.body$().isPresent$() && Long.$ne(request.body$().get$().contentLength$(),0 ) ) {
conn.setDoOutput$Z(true);
conn.setRequestProperty$S$S("Content-Length", Long.toString$J(request.body$().get$().contentLength$()));
} else {
conn.setRequestProperty$S$S("Content-Length", "0");
}if (request.timeout$().isPresent$()) {
var timeoutMillis=Long.$ival(Math.min$J$J(request.timeout$().get$().toMillis$(), 2147483647));
conn.setConnectTimeout$I(timeoutMillis);
conn.setReadTimeout$I(timeoutMillis);
}conn.connect$();
if (conn.getDoOutput$()) {
var body=request.body$().get$();
var os=conn.getOutputStream$();
os.write$BA(body.getBytes$());
}var statusCode=conn.getResponseCode$();
var headersMap=Clazz.new_([conn.getHeaderFields$()],$I$(1,1).c$$java_util_Map);
headersMap.remove$O(null);
var headers=$I$(2).of$java_util_Map(headersMap);
var responseInfo=Clazz.new_([statusCode, headers, $I$(4).HTTP_1_1],$I$(3,1).c$$I$io_github_warownia1_simplehttpclient_HttpHeaders$io_github_warownia1_simplehttpclient_HttpClient_Version);
var inputStream=statusCode < 400 ? conn.getInputStream$() : conn.getErrorStream$();
var body=handler.apply$io_github_warownia1_simplehttpclient_HttpResponse_ResponseInfo$java_io_InputStream(responseInfo, inputStream);
var uri;
try {
uri=conn.getURL$().toURI$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.net.URISyntaxException")){
e.printStackTrace$();
uri=request.uri$();
} else {
throw e;
}
}
return Clazz.new_($I$(5,1).c$$I$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpHeaders$O$java_net_URI,[statusCode, request, headers, body, uri]);
});

Clazz.newMeth(C$, 'sendAsync$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler$java_util_concurrent_Executor',  function (request, handler, executor) {
var supplier=((P$.SimpleHttpClient$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "SimpleHttpClient$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Supplier', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'get$',  function () {
try {
return this.b$['io.github.warownia1.simplehttpclient.impl.SimpleHttpClient'].send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler.apply(this.b$['io.github.warownia1.simplehttpclient.impl.SimpleHttpClient'], [this.$finals$.request, this.$finals$.handler]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('java.util.concurrent.CompletionException').c$$Throwable,[e]);
} else {
throw e;
}
}
});
})()
), Clazz.new_(P$.SimpleHttpClient$lambda2.$init$,[this, {request:request,handler:handler}]));
return $I$(6).supplyAsync$java_util_function_Supplier$java_util_concurrent_Executor(supplier, executor);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
