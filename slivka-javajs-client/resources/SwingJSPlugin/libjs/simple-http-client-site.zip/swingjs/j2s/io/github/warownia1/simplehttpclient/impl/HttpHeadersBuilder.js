(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'java.util.TreeMap','java.util.ArrayList','io.github.warownia1.simplehttpclient.HttpHeaders']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpHeadersBuilder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.headers=Clazz.new_($I$(1,1).c$$java_util_Comparator,[String.CASE_INSENSITIVE_ORDER]);
},1);

C$.$fields$=[['O',['headers','java.util.TreeMap']]]

Clazz.newMeth(C$, 'structuralCopy$',  function () {
var builder=Clazz.new_(C$);
for (var entry, $entry = this.headers.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var valuesCopy=Clazz.new_([entry.getValue$()],$I$(2,1).c$$java_util_Collection);
builder.headers.put$O$O(entry.getKey$(), valuesCopy);
}
return builder;
});

Clazz.newMeth(C$, 'addHeader$S$S',  function (name, value) {
this.headers.computeIfAbsent$O$java_util_function_Function(name, (P$.HttpHeadersBuilder$lambda1$||(P$.HttpHeadersBuilder$lambda1$=(((P$.HttpHeadersBuilder$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpHeadersBuilder$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$S','apply$O'],  function (k) { return (Clazz.new_($I$(2,1).c$$I,[1]));});
})()
), Clazz.new_(P$.HttpHeadersBuilder$lambda1.$init$,[this, null])))))).add$O(value);
});

Clazz.newMeth(C$, 'setHeader$S$S',  function (name, value) {
var values=Clazz.new_($I$(2,1).c$$I,[1]);
values.add$O(value);
this.headers.put$O$O(name, values);
});

Clazz.newMeth(C$, 'clear$',  function () {
this.headers.clear$();
});

Clazz.newMeth(C$, 'map$',  function () {
return this.headers;
});

Clazz.newMeth(C$, 'build$',  function () {
return $I$(3).of$java_util_Map(this.headers);
});

Clazz.newMeth(C$, 'toString',  function () {
return C$.superclazz.prototype.toString.apply(this, []) + " { " + this.map$() + " }" ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
