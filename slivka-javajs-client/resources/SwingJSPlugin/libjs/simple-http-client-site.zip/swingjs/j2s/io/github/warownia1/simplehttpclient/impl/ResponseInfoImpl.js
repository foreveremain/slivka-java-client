(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ResponseInfoImpl", null, null, [['io.github.warownia1.simplehttpclient.HttpResponse','io.github.warownia1.simplehttpclient.HttpResponse.ResponseInfo']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['statusCode'],'O',['headers','io.github.warownia1.simplehttpclient.HttpHeaders','version','io.github.warownia1.simplehttpclient.HttpClient.Version']]]

Clazz.newMeth(C$, 'c$$I$io_github_warownia1_simplehttpclient_HttpHeaders$io_github_warownia1_simplehttpclient_HttpClient_Version',  function (statusCode, headers, version) {
;C$.$init$.apply(this);
this.statusCode=statusCode;
this.headers=headers;
this.version=version;
}, 1);

Clazz.newMeth(C$, 'statusCode$',  function () {
return this.statusCode;
});

Clazz.newMeth(C$, 'headers$',  function () {
return this.headers;
});

Clazz.newMeth(C$, 'version$',  function () {
return this.version;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
