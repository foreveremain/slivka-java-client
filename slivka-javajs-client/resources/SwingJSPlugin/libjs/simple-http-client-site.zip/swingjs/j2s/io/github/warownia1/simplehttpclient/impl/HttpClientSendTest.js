(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'com.github.tomakehurst.wiremock.WireMockServer','com.github.tomakehurst.wiremock.core.WireMockConfiguration','com.github.tomakehurst.wiremock.client.WireMock','io.github.warownia1.simplehttpclient.HttpClient','io.github.warownia1.simplehttpclient.HttpRequest','java.net.URI',['io.github.warownia1.simplehttpclient.HttpResponse','.BodyHandlers'],'io.github.warownia1.simplehttpclient.impl.EmptyRequestBody','com.github.tomakehurst.wiremock.matching.RequestPatternBuilder','com.github.tomakehurst.wiremock.http.RequestMethod','java.nio.charset.StandardCharsets','io.github.warownia1.simplehttpclient.impl.ByteArrayRequestBody','java.util.Map','java.util.List']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpClientSendTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['server','com.github.tomakehurst.wiremock.WireMockServer']]]

Clazz.newMeth(C$, 'setupServer$',  function () {
this.server=Clazz.new_([$I$(2).wireMockConfig$().dynamicPort$()],$I$(1,1).c$$com_github_tomakehurst_wiremock_core_Options);
this.server.start$();
$I$(3,"configureFor$I",[this.server.port$()]);
});

Clazz.newMeth(C$, 'teardownServer$',  function () {
this.server.stop$();
});

Clazz.newMeth(C$, 'resetWireMock$',  function () {
$I$(3).reset$();
});

Clazz.newMeth(C$, 'createSimplePath$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["/"]), Clazz.array(java.lang.Object, -1, ["/index"]), Clazz.array(java.lang.Object, -1, ["/index.html"]), Clazz.array(java.lang.Object, -1, ["/path/to/resource"]), Clazz.array(java.lang.Object, -1, ["/page/15"]), Clazz.array(java.lang.Object, -1, ["/alpha%20bravo"]), Clazz.array(java.lang.Object, -1, ["/alpha-bravo"]), Clazz.array(java.lang.Object, -1, ["/?key=val"]), Clazz.array(java.lang.Object, -1, ["/?param1=A&param2=B"]), Clazz.array(java.lang.Object, -1, ["/index?key=val"])]);
});

Clazz.newMeth(C$, 'send_SimplePath_RequestPathMatches$S',  function (path) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3).get$S(path).willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.url$S(path)])]).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
$I$(3,"verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder",[$I$(3,"getRequestedFor$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).urlEqualTo$S(path)])]);
});

Clazz.newMeth(C$, 'send_EmptyPath_PathIsRoot$',  function () {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3,"any$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).anyUrl$()]).willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.baseUrl$()])]).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
$I$(3,"verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder",[$I$(3,"getRequestedFor$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).urlEqualTo$S("/")])]);
});

Clazz.newMeth(C$, 'send_PathWithFragment_FragmentNotSent$S',  function (path) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3,"any$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).anyUrl$()]).willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.url$S(path) + "#fragment"])]).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
$I$(3,"verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder",[$I$(3,"getRequestedFor$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).urlEqualTo$S(path)])]);
});

Clazz.newMeth(C$, 'createHttpMethod$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["GET"]), Clazz.array(java.lang.Object, -1, ["HEAD"]), Clazz.array(java.lang.Object, -1, ["POST"]), Clazz.array(java.lang.Object, -1, ["PUT"]), Clazz.array(java.lang.Object, -1, ["DELETE"]), Clazz.array(java.lang.Object, -1, ["OPTIONS"]), Clazz.array(java.lang.Object, -1, ["TRACE"]), Clazz.array(java.lang.Object, -1, ["PATCH"])]);
});

Clazz.newMeth(C$, 'send_TestMethodSent$S',  function (method) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3,"any$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).anyUrl$()]).willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.baseUrl$()])]).method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body(method, $I$(8).instance).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
$I$(3,"verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder",[$I$(9,"newRequestPattern$com_github_tomakehurst_wiremock_http_RequestMethod$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(10).fromString$S(method), $I$(3).urlEqualTo$S("/")])]);
});

Clazz.newMeth(C$, 'createInvalidHttpMethod$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["CUSTOM"]), Clazz.array(java.lang.Object, -1, ["get"]), Clazz.array(java.lang.Object, -1, ["A METHOD"])]);
});

Clazz.newMeth(C$, 'send_InvalidHttpMethod_ThrowProtocolException$S',  function (method) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3,"any$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).anyUrl$()]).willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.baseUrl$()])]).method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body(method, $I$(8).instance).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
});

Clazz.newMeth(C$, 'createRequestContent$',  function () {
var strings=Clazz.array(String, -1, ["", "Content", "Request Content", "param1=val&param2=val", "Multi\r\nline\r\ncontent", "\u00fa\u00f1\u00ec\u00c7\u00f3\u00d0\u00cb"]);
var args=Clazz.array(java.lang.Object, [strings.length, null]);
for (var i=0; i < strings.length; i++) {
args[i]=Clazz.array(java.lang.Object, -1, [strings[i].getBytes$java_nio_charset_Charset($I$(11).UTF_8)]);
}
return args;
});

Clazz.newMeth(C$, 'send_SendBody_ContentReceived$BA',  function (body) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3).post$S("/").willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.baseUrl$()])]).method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("POST", Clazz.new_($I$(12,1).c$$BA,[body])).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
$I$(3,"verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder",[$I$(3,"postRequestedFor$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).urlPathEqualTo$S("/")]).withRequestBody$com_github_tomakehurst_wiremock_matching_ContentPattern($I$(3).binaryEqualTo$BA(body))]);
});

Clazz.newMeth(C$, 'send_SendBody_ContentLengthSet$BA',  function (body) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3).post$S("/").willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.baseUrl$()])]).method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("POST", Clazz.new_($I$(12,1).c$$BA,[body])).build$();
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(7).discarding$());
$I$(3,"verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder",[$I$(3,"postRequestedFor$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).urlPathEqualTo$S("/")]).withHeader$S$com_github_tomakehurst_wiremock_matching_StringValuePattern("Content-Length", $I$(3,"equalTo$S",[Integer.toString$I(body.length)]))]);
});

Clazz.newMeth(C$, 'createHeaderValues$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(13,"of$O$O",["A", $I$(14).of$O("B")])]), Clazz.array(java.lang.Object, -1, [$I$(13,"of$O$O",["A", $I$(14).of$O$O("B", "C")])]), Clazz.array(java.lang.Object, -1, [$I$(13,"of$O$O",["A", $I$(14).of$O$O$O("B", "C", "D")])]), Clazz.array(java.lang.Object, -1, [$I$(13,"of$O$O$O$O",["A", $I$(14).of$O("B"), "X", $I$(14).of$O("Y")])]), Clazz.array(java.lang.Object, -1, [$I$(13,"of$O$O$O$O",["A", $I$(14).of$O("B"), "X", $I$(14).of$O$O("Y", "Z")])]), Clazz.array(java.lang.Object, -1, [$I$(13,"of$O$O$O$O",["A", $I$(14).of$O$O("B", "C"), "X", $I$(14).of$O$O$O("Y", "Z", "T")])])]);
});

Clazz.newMeth(C$, 'send_SetHeaders_HeadersPresent$java_util_Map',  function (headersMap) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3,"any$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).anyUrl$()]).willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$())]);
var client=$I$(4).newHttpClient$();
var request=$I$(5,"newBuilder$java_net_URI",[$I$(6,"create$S",[this.server.baseUrl$()])]);
for (var entry, $entry = headersMap.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
entry.getValue$().forEach$java_util_function_Consumer(((P$.HttpClientSendTest$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpClientSendTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (it) { return (this.$finals$.request.header$S$S(this.$finals$.entry.getKey$(), it));});
})()
), Clazz.new_(P$.HttpClientSendTest$lambda1.$init$,[this, {request:request,entry:entry}])));
}
client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request.build$(), $I$(7).discarding$());
var reqPattern=$I$(3,"getRequestedFor$com_github_tomakehurst_wiremock_matching_UrlPattern",[$I$(3).urlEqualTo$S("/")]);
for (var entry, $entry = headersMap.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var headerName=entry.getKey$();
for (var headerValue, $headerValue = entry.getValue$().iterator$(); $headerValue.hasNext$()&&((headerValue=($headerValue.next$())),1);) {
reqPattern=reqPattern.withHeader$S$com_github_tomakehurst_wiremock_matching_StringValuePattern(headerName, $I$(3).equalTo$S(headerValue));
}
}
$I$(3).verify$com_github_tomakehurst_wiremock_matching_RequestPatternBuilder(reqPattern);
});
C$.$getAnn$ = function(){ return [
[['M:createSimplePath','Object[][]','createSimplePath$',['org.testng.annotations.DataProvider']],['name="SimplePath" ']],
  [['M:createHttpMethod','.','createHttpMethod$',['org.testng.annotations.DataProvider']],['name="HttpMethod" ']],
  [['M:createInvalidHttpMethod','.','createInvalidHttpMethod$',['org.testng.annotations.DataProvider']],['name="InvalidHttpMethod" ']],
  [['M:createRequestContent','.','createRequestContent$',['org.testng.annotations.DataProvider']],['name="RequestContent" ']],
  [['M:createHeaderValues','.','createHeaderValues$',['org.testng.annotations.DataProvider']],['name="Headers" ']]]}

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
