(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'io.github.warownia1.simplehttpclient.impl.HttpHeadersBuilder','io.github.warownia1.simplehttpclient.impl.EmptyRequestBody','java.util.Objects','java.util.Locale','String','io.github.warownia1.simplehttpclient.impl.ImmutableHttpRequest']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleHttpRequestBuilder", null, null, [['io.github.warownia1.simplehttpclient.HttpRequest','io.github.warownia1.simplehttpclient.HttpRequest.Builder']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.method="GET";
this.headers=Clazz.new_($I$(1,1));
this.body=$I$(2).getInstance$();
},1);

C$.$fields$=[['S',['method'],'O',['uri','java.net.URI','headers','io.github.warownia1.simplehttpclient.impl.HttpHeadersBuilder','body','io.github.warownia1.simplehttpclient.HttpRequest.Body','timeout','java.time.Duration']]]

Clazz.newMeth(C$, 'uri$java_net_URI',  function (uri) {
$I$(3).requireNonNull$O(uri);
C$.checkURI$java_net_URI(uri);
this.uri=uri;
return this;
});

Clazz.newMeth(C$, 'checkURI$java_net_URI',  function (uri) {
var scheme=uri.getScheme$();
if (scheme == null ) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["URI with undefined scheme"]);
scheme=scheme.toLowerCase$java_util_Locale($I$(4).US);
if (!scheme.equals$O("https") && !scheme.equals$O("http") ) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(5,"format$S$OA",["invalid URI scheme %s", Clazz.array(java.lang.Object, -1, [scheme])])]);
if (uri.getHost$() == null ) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(5,"format$S$OA",["unsupported URI %s", Clazz.array(java.lang.Object, -1, [uri])])]);
}, 1);

Clazz.newMeth(C$, 'header$S$S',  function (name, value) {
$I$(3).requireNonNull$O(name);
$I$(3).requireNonNull$O(value);
this.headers.addHeader$S$S(name, value);
return this;
});

Clazz.newMeth(C$, 'HEAD$',  function () {
return this.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("HEAD", $I$(2).getInstance$());
});

Clazz.newMeth(C$, 'GET$',  function () {
return this.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("GET", $I$(2).getInstance$());
});

Clazz.newMeth(C$, 'POST$io_github_warownia1_simplehttpclient_HttpRequest_Body',  function (body) {
$I$(3).requireNonNull$O(body);
return this.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("POST", body);
});

Clazz.newMeth(C$, 'PUT$io_github_warownia1_simplehttpclient_HttpRequest_Body',  function (body) {
$I$(3).requireNonNull$O(body);
return this.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("PUT", body);
});

Clazz.newMeth(C$, 'DELETE$',  function () {
return this.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("DELETE", $I$(2).getInstance$());
});

Clazz.newMeth(C$, 'method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body',  function (method, body) {
$I$(3).requireNonNull$O(method);
if (method.equals$O("")) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["illegal method <empty string>"]);
this.method=method;
this.body=$I$(3).requireNonNull$O(body);
return this;
});

Clazz.newMeth(C$, 'timeout$java_time_Duration',  function (duration) {
if (duration == null ) {
this.timeout=null;
return this;
}if (duration.isNegative$() || duration.isZero$() ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["invalid duration: " + duration]);
}this.timeout=duration;
return this;
});

Clazz.newMeth(C$, 'build$',  function () {
if (this.uri == null ) throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["uri is null"]);
return Clazz.new_($I$(6,1).c$$io_github_warownia1_simplehttpclient_impl_SimpleHttpRequestBuilder,[this]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
