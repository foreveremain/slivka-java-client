(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),p$1={},I$=[[0,'java.nio.ByteBuffer','java.net.URLEncoder','io.github.warownia1.simplehttpclient.impl.ByteArrayRequestBody']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "WWWFormURLEncodedRequestBodyBuilder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bodyBuffer=$I$(1).allocate$I(256);
},1);

C$.$fields$=[['O',['bodyBuffer','java.nio.ByteBuffer']]]

Clazz.newMeth(C$, 'append$S$S',  function (key, value) {
var encodedKey;
var encodedValue;
try {
encodedKey=$I$(2).encode$S$S(key, "UTF-8").replaceAll$S$S("\\*", "%2A").getBytes$S("UTF-8");
encodedValue=$I$(2).encode$S$S(value, "UTF-8").replaceAll$S$S("\\*", "%2A").getBytes$S("UTF-8");
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.UnsupportedEncodingException")){
throw Clazz.new_(Clazz.load('java.io.UncheckedIOException').c$$java_io_IOException,[e]);
} else {
throw e;
}
}
if (encodedKey.length + encodedValue.length + 2  >= this.bodyBuffer.remaining$()) {
p$1.growBuffer$I.apply(this, [encodedKey.length + encodedValue.length + 2 ]);
}this.bodyBuffer.put$B(38).put$BA(encodedKey).put$B(61).put$BA(encodedValue);
return this;
});

Clazz.newMeth(C$, 'growBuffer$I',  function (requiredRemaining) {
var requiredCapacity=this.bodyBuffer.position$() + requiredRemaining;
var capacity=this.bodyBuffer.capacity$();
while (capacity <= requiredCapacity){
capacity+=(capacity/2|0);
}
this.bodyBuffer.flip$();
var newBuffer=$I$(1).allocate$I(capacity);
newBuffer.put$java_nio_ByteBuffer(this.bodyBuffer);
this.bodyBuffer=newBuffer;
}, p$1);

Clazz.newMeth(C$, 'build$',  function () {
var buffer=this.bodyBuffer.duplicate$();
buffer.flip$();
if (buffer.limit$() > 0) buffer.get$();
return Clazz.new_([buffer.array$(), buffer.arrayOffset$() + buffer.position$(), buffer.remaining$()],$I$(3,1).c$$BA$I$I);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
