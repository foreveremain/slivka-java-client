(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),p$1={},I$=[[0,'java.util.concurrent.CompletableFuture','io.github.warownia1.simplehttpclient.impl.HttpHeadersBuilder','java.io.ByteArrayInputStream','java.nio.charset.StandardCharsets','io.github.warownia1.simplehttpclient.impl.ResponseInfoImpl',['io.github.warownia1.simplehttpclient.HttpClient','.Version'],'io.github.warownia1.simplehttpclient.impl.SimpleHttpResponse']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JQueryHttpClient", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'io.github.warownia1.simplehttpclient.HttpClient');
C$.$classes$=[['AjaxDoneConsumer',8],['AjaxFailConsumer',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler',  function (request, handler) {
var jqXHR=p$1.doAjax$io_github_warownia1_simplehttpclient_HttpRequest$Z.apply(this, [request, false]);
return p$1.responseFromJqXHR$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler$O.apply(this, [request, handler, jqXHR]);
});

Clazz.newMeth(C$, 'sendAsync$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler$java_util_concurrent_Executor',  function (request, handler, executor) {
var responseFuture=Clazz.new_($I$(1,1));
var doneConsumer=((P$.JQueryHttpClient$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "JQueryHttpClient$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['io.github.warownia1.simplehttpclient.impl.JQueryHttpClient','io.github.warownia1.simplehttpclient.impl.JQueryHttpClient.AjaxDoneConsumer']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$S$O','accept$O$O$O'],  function (data, textStatus, jqXHR) {
try {
var response=p$1.responseFromJqXHR$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler$O.apply(this.b$['io.github.warownia1.simplehttpclient.impl.JQueryHttpClient'], [this.$finals$.request, this.$finals$.handler, jqXHR]);
this.$finals$.responseFuture.complete$O(response);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.$finals$.responseFuture.completeExceptionally$Throwable(e);
} else {
throw e;
}
}
});
})()
), Clazz.new_(P$.JQueryHttpClient$lambda1.$init$,[this, {request:request,responseFuture:responseFuture,handler:handler}]));
var failConsumer=((P$.JQueryHttpClient$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "JQueryHttpClient$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['io.github.warownia1.simplehttpclient.impl.JQueryHttpClient','io.github.warownia1.simplehttpclient.impl.JQueryHttpClient.AjaxFailConsumer']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$O$S$S','accept$O$O$O'],  function (jqXHR, textStatus, errorThrown) {
try {
var response=p$1.responseFromJqXHR$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler$O.apply(this.b$['io.github.warownia1.simplehttpclient.impl.JQueryHttpClient'], [this.$finals$.request, this.$finals$.handler, jqXHR]);
this.$finals$.responseFuture.complete$O(response);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.$finals$.responseFuture.completeExceptionally$Throwable(e);
} else {
throw e;
}
}
});
})()
), Clazz.new_(P$.JQueryHttpClient$lambda2.$init$,[this, {request:request,responseFuture:responseFuture,handler:handler}]));
var XHRHandler=p$1.doAjax$io_github_warownia1_simplehttpclient_HttpRequest$Z.apply(this, [request, true]);

XHRHandler.done(doneConsumer.accept$S$S$O);
XHRHandler.fail(failConsumer.accept$O$S$S);
return responseFuture;
});

Clazz.newMeth(C$, 'responseFromJqXHR$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler$O',  function (request, handler, jqXHR) {
var statusCode=jqXHR.status ||0;
var responseHeaders=Clazz.new_($I$(2,1));
var allHeadersText=jqXHR.getAllResponseHeaders() ||"";
for (var line, $line = 0, $$line = allHeadersText.split$S("\\n"); $line<$$line.length&&((line=($$line[$line])),1);$line++) {
var idx=line.indexOf$I(":");
if (idx < 0) continue;
var header=line.substring$I$I(0, idx);
for (var value, $value = 0, $$value = line.substring$I(idx + 1).trim$().split$S(","); $value<$$value.length&&((value=($$value[$value])),1);$value++) {
responseHeaders.addHeader$S$S(header, value.trim$());
}
}
var responseText=jqXHR.responseText ||"";
var stream=Clazz.new_([responseText.getBytes$java_nio_charset_Charset($I$(4).UTF_8)],$I$(3,1).c$$BA);
var headers=responseHeaders.build$();
var responseInfo=Clazz.new_([statusCode, headers, $I$(6).HTTP_1_1],$I$(5,1).c$$I$io_github_warownia1_simplehttpclient_HttpHeaders$io_github_warownia1_simplehttpclient_HttpClient_Version);
return Clazz.new_([statusCode, request, headers, handler.apply$io_github_warownia1_simplehttpclient_HttpResponse_ResponseInfo$java_io_InputStream(responseInfo, stream), request.uri$()],$I$(7,1).c$$I$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpHeaders$O$java_net_URI);
}, p$1);

Clazz.newMeth(C$, 'doAjax$io_github_warownia1_simplehttpclient_HttpRequest$Z',  function (request, async) {
var url=request.uri$().toString();
var method=request.method$();
var headers={} ||null;
for (var entry, $entry = request.headers$().map$().entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {

headers[entry.getKey$()] = entry.getValue$().toArray$();
}
var data=null;
if (request.body$().isPresent$()) {
data=request.body$().get$().getBytes$();
}var timeout=0;
if (request.timeout$().isPresent$()) {
timeout=request.timeout$().get$().toMillis$();
}{
return jQuery.ajax(url, { async: async, contentType: false, data: data, dataType: "text", headers: headers, method: method, processData: false, timeout: timeout })
}
}, p$1);
;
(function(){/*i*/var C$=Clazz.newInterface(P$.JQueryHttpClient, "AjaxDoneConsumer", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.JQueryHttpClient, "AjaxFailConsumer", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
