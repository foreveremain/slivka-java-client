(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient"),I$=[[0,'io.github.warownia1.simplehttpclient.impl.SimpleHttpRequestBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpRequest", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Builder',9],['Body',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'newBuilder$java_net_URI',  function (uri) {
return C$.newBuilder$().uri$java_net_URI(uri);
}, 1);

Clazz.newMeth(C$, 'newBuilder$',  function () {
return Clazz.new_($I$(1,1));
}, 1);
;
(function(){/*i*/var C$=Clazz.newInterface(P$.HttpRequest, "Builder", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.HttpRequest, "Body", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
