(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'io.github.warownia1.simplehttpclient.impl.HttpHeadersBuilder','org.testng.Assert','java.util.List','java.util.Set']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpHeadersBuilderTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['builder','io.github.warownia1.simplehttpclient.impl.HttpHeadersBuilder']]]

Clazz.newMeth(C$, 'setupBuilder$',  function () {
this.builder=Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'addHeader_NewKey_CreateKeyValue$',  function () {
this.builder.addHeader$S$S("Accept", "text/css");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O("text/css")]);
});

Clazz.newMeth(C$, 'addHeader_ExistingKey_AppendValue$',  function () {
this.builder.addHeader$S$S("Accept", "text/css");
this.builder.addHeader$S$S("Accept", "text/plain");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O$O("text/css", "text/plain")]);
});

Clazz.newMeth(C$, 'addHeader_DifferentKey_CreateKeyValue$',  function () {
this.builder.addHeader$S$S("Accept", "text/css");
this.builder.addHeader$S$S("Content-Length", "5");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O("text/css")]);
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Content-Length"), $I$(3).of$O("5")]);
});

Clazz.newMeth(C$, 'addHeader_ExistingKeyCaseInsensitive_AppendValue$',  function () {
this.builder.addHeader$S$S("Accept", "text/css");
this.builder.addHeader$S$S("accept", "text/html");
this.builder.addHeader$S$S("ACCEPT", "text/plain");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O$O$O("text/css", "text/html", "text/plain")]);
});

Clazz.newMeth(C$, 'setHeader_NewKey_CreateKeyValue$',  function () {
this.builder.setHeader$S$S("Accept", "text/css");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O("text/css")]);
});

Clazz.newMeth(C$, 'setHeader_ExistingKey_ReplaceValue$',  function () {
this.builder.addHeader$S$S("Accept", "text/css");
this.builder.setHeader$S$S("Accept", "text/plain");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O("text/plain")]);
});

Clazz.newMeth(C$, 'setHeader_ExistingKeyCaseInsensitive_ReplaceValue$',  function () {
this.builder.addHeader$S$S("Accept", "text/css");
this.builder.setHeader$S$S("accept", "text/plain");
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(3).of$O("text/plain")]);
});

Clazz.newMeth(C$, 'clear_ClearHeaders_NoKeys$',  function () {
this.builder.addHeader$S$S("Accept", "text/plain");
this.builder.clear$();
var headers=this.builder.build$();
$I$(2,"assertEquals$java_util_Set$java_util_Set",[headers.map$().keySet$(), $I$(4).of$()]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
