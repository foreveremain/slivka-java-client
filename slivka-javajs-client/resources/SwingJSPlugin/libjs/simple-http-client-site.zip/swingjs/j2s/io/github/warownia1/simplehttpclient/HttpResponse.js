(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "HttpResponse", function(){
});
C$.$classes$=[['ResponseInfo',9],['BodyHandler',9],['BodyHandlers',9]];
;
(function(){/*i*/var C$=Clazz.newInterface(P$.HttpResponse, "ResponseInfo", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.HttpResponse, "BodyHandler", function(){
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.HttpResponse, "BodyHandlers", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'ofString$',  function () {
return (P$.HttpResponse$BodyHandlers$lambda1$||(P$.HttpResponse$BodyHandlers$lambda1$=(((P$.HttpResponse$BodyHandlers$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpResponse$BodyHandlers$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['io.github.warownia1.simplehttpclient.HttpResponse','io.github.warownia1.simplehttpclient.HttpResponse.BodyHandler']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$io_github_warownia1_simplehttpclient_HttpResponse_ResponseInfo$java_io_InputStream','apply$O$O'],  function (info, stream) { return ( String.instantialize(stream.readAllBytes$()));});
})()
), Clazz.new_(P$.HttpResponse$BodyHandlers$lambda1.$init$,[this, null])))));
}, 1);

Clazz.newMeth(C$, 'discarding$',  function () {
return (P$.HttpResponse$BodyHandlers$lambda2$||(P$.HttpResponse$BodyHandlers$lambda2$=(((P$.HttpResponse$BodyHandlers$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpResponse$BodyHandlers$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['io.github.warownia1.simplehttpclient.HttpResponse','io.github.warownia1.simplehttpclient.HttpResponse.BodyHandler']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$io_github_warownia1_simplehttpclient_HttpResponse_ResponseInfo$java_io_InputStream','apply$O$O'],  function (info, stream) { return (null);});
})()
), Clazz.new_(P$.HttpResponse$BodyHandlers$lambda2.$init$,[this, null])))));
}, 1);

Clazz.newMeth(C$, 'ofInputStream$',  function () {
return (P$.HttpResponse$BodyHandlers$lambda3$||(P$.HttpResponse$BodyHandlers$lambda3$=(((P$.HttpResponse$BodyHandlers$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpResponse$BodyHandlers$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['io.github.warownia1.simplehttpclient.HttpResponse','io.github.warownia1.simplehttpclient.HttpResponse.BodyHandler']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$io_github_warownia1_simplehttpclient_HttpResponse_ResponseInfo$java_io_InputStream','apply$O$O'],  function (info, stream) { return (stream);});
})()
), Clazz.new_(P$.HttpResponse$BodyHandlers$lambda3.$init$,[this, null])))));
}, 1);
})()
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
