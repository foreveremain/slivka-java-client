(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "EmptyRequestBody", null, null, [['io.github.warownia1.simplehttpclient.HttpRequest','io.github.warownia1.simplehttpclient.HttpRequest.Body']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['instance','io.github.warownia1.simplehttpclient.impl.EmptyRequestBody','body','byte[]']]]

Clazz.newMeth(C$, 'getInstance$',  function () {
return C$.instance;
}, 1);

Clazz.newMeth(C$, 'getBytes$',  function () {
return C$.body;
});

Clazz.newMeth(C$, 'contentLength$',  function () {
return 0;
});

C$.$static$=function(){C$.$static$=0;
C$.instance=Clazz.new_(C$);
C$.body=Clazz.array(Byte.TYPE, [0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
