(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'com.github.tomakehurst.wiremock.WireMockServer','com.github.tomakehurst.wiremock.core.WireMockConfiguration','com.github.tomakehurst.wiremock.client.WireMock','java.util.Arrays','java.util.stream.Stream','io.github.warownia1.simplehttpclient.HttpClient','io.github.warownia1.simplehttpclient.HttpRequest','java.net.URI',['io.github.warownia1.simplehttpclient.HttpResponse','.BodyHandlers'],'org.testng.Assert','java.util.Map','java.util.List','java.util.HashMap','io.github.warownia1.simplehttpclient.HttpHeaders']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpClientReplyTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['server','com.github.tomakehurst.wiremock.WireMockServer']]]

Clazz.newMeth(C$, 'setupServer$',  function () {
this.server=Clazz.new_([$I$(2).wireMockConfig$().dynamicPort$()],$I$(1,1).c$$com_github_tomakehurst_wiremock_core_Options);
this.server.start$();
$I$(3,"configureFor$I",[this.server.port$()]);
});

Clazz.newMeth(C$, 'teardownServer$',  function () {
this.server.stop$();
});

Clazz.newMeth(C$, 'resetWireMock$',  function () {
$I$(3).reset$();
});

Clazz.newMeth(C$, 'informationalStatusCode$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(100), "Continue"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(101), "Switching Protocols"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(102), "Processing"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(103), "Early Hints"])]);
});

Clazz.newMeth(C$, 'successfulStatusCode$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(200), "OK"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(201), "Created"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(202), "Accepted"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(203), "Non-Authoritative Information"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(204), "No Content"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(205), "Reset Content"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(206), "Partial Content"])]);
});

Clazz.newMeth(C$, 'redirectionStatusCode$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(300), "Multiple Choices"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(301), "Moved Permanently"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(302), "Found"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(303), "See Other"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(304), "Not Modified"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(307), "Temporary Redirect"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(308), "Permanent Redirect"])]);
});

Clazz.newMeth(C$, 'clientErrorStatusCode$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(400), "Bad Request"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(401), "Unauthorised"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(403), "Forbidden"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(404), "Not Found"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(405), "Method Not Allowed"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(406), "Not Acceptable"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(407), "Proxy Authentication Required"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(408), "Request Timeout"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(409), "Conflict"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(410), "Gone"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(411), "Length Required"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(415), "Unsupported Media Type"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(418), "I\'m a teapot"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(429), "Too Many Requests"])]);
});

Clazz.newMeth(C$, 'serverErrorStatusCode$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(500), "Internal Server Error"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(501), "Not Implemented"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(502), "Bad Gateway"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(503), "Service Unavailable"]), Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(504), "Gateway Timeout"])]);
});

Clazz.newMeth(C$, 'createAnyStatusCode$',  function () {
var stream=$I$(4,"stream$OA",[this.successfulStatusCode$()]);
stream=$I$(5,"concat$java_util_stream_Stream$java_util_stream_Stream",[stream, $I$(4,"stream$OA",[this.redirectionStatusCode$()])]);
stream=$I$(5,"concat$java_util_stream_Stream$java_util_stream_Stream",[stream, $I$(4,"stream$OA",[this.clientErrorStatusCode$()])]);
stream=$I$(5,"concat$java_util_stream_Stream$java_util_stream_Stream",[stream, $I$(4,"stream$OA",[this.serverErrorStatusCode$()])]);
return stream.iterator$();
});

Clazz.newMeth(C$, 'send_ReceiveResponse_StatusMatches$I$S',  function (code, message) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3).get$S("/").willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).aResponse$().withStatus$I(code))]);
var client=$I$(6).newHttpClient$();
var request=$I$(7,"newBuilder$java_net_URI",[$I$(8,"create$S",[this.server.baseUrl$()])]).build$();
var response=client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(9).discarding$());
$I$(10,"assertEquals$I$I",[response.statusCode$(), code]);
});

Clazz.newMeth(C$, 'responseBody$',  function () {
return Clazz.array(String, -2, [Clazz.array(String, -1, [""]), Clazz.array(String, -1, ["Hello world"]), Clazz.array(String, -1, ["\u00fa\u00f1\u00ec\u00c7\u00f3\u00d0\u00cb"]), Clazz.array(String, -1, ["{\"key\": \"value\"}"]), Clazz.array(String, -1, ["<html><head></head><body></body></html>"])]);
});

Clazz.newMeth(C$, 'send_ReceiveBody_ContentMatches$S',  function (body) {
$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3).get$S("/").willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder($I$(3).ok$S(body))]);
var client=$I$(6).newHttpClient$();
var request=$I$(7,"newBuilder$java_net_URI",[$I$(8,"create$S",[this.server.baseUrl$()])]).build$();
var response=client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(9).ofString$());
$I$(10,"assertEquals$S$S",[response.body$(), body]);
});

Clazz.newMeth(C$, 'responseHeaders$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(11,"of$O$O$O$O",["Access-Control-Allow-Origin", $I$(12).of$O("*"), "Content-Length", $I$(12).of$O("0")])]), Clazz.array(java.lang.Object, -1, [$I$(11,"of$O$O$O$O",["Location", $I$(12).of$O("http://example.org"), "Content-Length", $I$(12).of$O("0")])]), Clazz.array(java.lang.Object, -1, [$I$(11,"of$O$O$O$O$O$O",["Content-Type", $I$(12,"of$O",["text/plain; charset=utf-8"]), "Cache-Control", $I$(12,"of$O",["max-age=3600"]), "Content-Length", $I$(12).of$O("0")])]), Clazz.array(java.lang.Object, -1, [$I$(11,"of$O$O$O$O$O$O$O$O",["Connection", $I$(12).of$O("Keep"), "Content-Length", $I$(12).of$O("321"), "Content-Language", $I$(12).of$O("pl"), "Server", $I$(12).of$O("WireMock")])]), Clazz.array(java.lang.Object, -1, [$I$(11,"of$O$O$O$O",["Last-Modified", $I$(12).of$O("Thu, 13 Apr 2023 14:21:38 GMT"), "Content-Length", $I$(12).of$O("0")])])]);
});

Clazz.newMeth(C$, 'send_ReceiveHeaders_HeadersMatch$java_util_Map',  function (headersMap) {
var responseDef=$I$(3).ok$();
headersMap.forEach$java_util_function_BiConsumer(((P$.HttpClientReplyTest$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpClientReplyTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (key, values) { return (this.$finals$.responseDef.withHeader$S$SA(key, values.toArray$OA(Clazz.array(String, [1]))));});
})()
), Clazz.new_(P$.HttpClientReplyTest$lambda1.$init$,[this, {responseDef:responseDef}])));
var mapping=$I$(3,"stubFor$com_github_tomakehurst_wiremock_client_MappingBuilder",[$I$(3).get$S("/").willReturn$com_github_tomakehurst_wiremock_client_ResponseDefinitionBuilder(responseDef)]);
var client=$I$(6).newHttpClient$();
var request=$I$(7,"newBuilder$java_net_URI",[$I$(8,"create$S",[this.server.baseUrl$()])]).build$();
var response=client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(9).discarding$());
var expected=Clazz.new_($I$(13,1).c$$java_util_Map,[headersMap]);
expected.put$O$O("Matched-Stub-Id", $I$(12,"of$O",[mapping.getId$().toString()]));
expected.put$O$O("Vary", $I$(12).of$O("Accept-Encoding, User-Agent"));
$I$(10,"assertEquals$O$O",[response.headers$(), $I$(14).of$java_util_Map(expected)]);
});
C$.$getAnn$ = function(){ return [
[['M:createAnyStatusCode','java.util.Iterator','createAnyStatusCode$',['org.testng.annotations.DataProvider']],['name="AnyStatusCode" ']]]}

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
