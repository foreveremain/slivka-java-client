(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient"),I$=[[0,'java.util.Objects','java.util.TreeMap','java.util.TreeSet','java.util.ArrayList','java.util.Collections','java.util.Optional','java.util.Locale']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpHeaders");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['headers','java.util.Map']]]

Clazz.newMeth(C$, 'c$$java_util_Map',  function (headers) {
;C$.$init$.apply(this);
this.headers=headers;
}, 1);

Clazz.newMeth(C$, 'of$java_util_Map',  function (map) {
$I$(1).requireNonNull$O(map);
var headers=Clazz.new_($I$(2,1).c$$java_util_Comparator,[String.CASE_INSENSITIVE_ORDER]);
var notAdded=Clazz.new_($I$(3,1).c$$java_util_Comparator,[String.CASE_INSENSITIVE_ORDER]);
map.forEach$java_util_function_BiConsumer(((P$.HttpHeaders$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "HttpHeaders$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (key, value) {
var headerName=$I$(1).requireNonNull$O$S(key, "header name").trim$();
if (headerName.isEmpty$()) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["empty header name"]);
}$I$(1).requireNonNull$O$S(value, "header values");
var headerValues=Clazz.new_($I$(4,1).c$$I,[1]);
for (var headerValue, $headerValue = value.iterator$(); $headerValue.hasNext$()&&((headerValue=($headerValue.next$())),1);) {
headerValue=$I$(1).requireNonNull$O$S(headerValue, "header value").trim$();
headerValues.add$O(headerValue);
}
if (this.$finals$.headers.containsKey$O(headerName) || this.$finals$.notAdded.contains$O(headerName) ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["duplicate header: " + headerName]);
}if (!headerValues.isEmpty$()) {
this.$finals$.headers.put$O$O(headerName, $I$(5).unmodifiableList$java_util_List(headerValues));
} else {
this.$finals$.notAdded.add$O(headerName);
}});
})()
), Clazz.new_(P$.HttpHeaders$lambda1.$init$,[this, {notAdded:notAdded,headers:headers}])));
return Clazz.new_(C$.c$$java_util_Map,[$I$(5).unmodifiableMap$java_util_Map(headers)]);
}, 1);

Clazz.newMeth(C$, 'map$',  function () {
return this.headers;
});

Clazz.newMeth(C$, 'allValues$S',  function (name) {
$I$(1).requireNonNull$O(name);
var values=this.headers.get$O(name);
return values != null  ? values : $I$(5).emptyList$();
});

Clazz.newMeth(C$, 'firstValue$S',  function (name) {
var values=this.allValues$S(name);
if (values.isEmpty$()) return $I$(6).empty$();
 else return $I$(6,"ofNullable$O",[values.get$I(0)]);
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (!(Clazz.instanceOf(obj, "io.github.warownia1.simplehttpclient.HttpHeaders"))) return false;
return this.map$().equals$O((obj).map$());
});

Clazz.newMeth(C$, 'hashCode$',  function () {
var h=0;
for (var e, $e = this.map$().entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
h+=C$.entryHash$java_util_Map_Entry(e);
}
return h;
});

Clazz.newMeth(C$, 'entryHash$java_util_Map_Entry',  function (e) {
var keyHash=e.getKey$().toLowerCase$java_util_Locale($I$(7).ROOT).hashCode$();
var valHash=e.getValue$().hashCode$();
return keyHash ^ valHash;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return C$.superclazz.prototype.toString.apply(this, []) + " { " + this.map$() + " }" ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
