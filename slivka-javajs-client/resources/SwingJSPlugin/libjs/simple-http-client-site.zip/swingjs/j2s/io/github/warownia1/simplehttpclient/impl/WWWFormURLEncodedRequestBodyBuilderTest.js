(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'org.testng.Assert','java.nio.charset.StandardCharsets','java.util.List','io.github.warownia1.simplehttpclient.impl.WWWFormURLEncodedRequestBodyBuilder',['java.util.AbstractMap','.SimpleImmutableEntry']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "WWWFormURLEncodedRequestBodyBuilderTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'singleParameter$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [C$.entry$S$S("snack", "chocolate"), "snack=chocolate"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("snack", "apricot jelly"), "snack=apricot+jelly"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("snack", "apple=orange"), "snack=apple%3Dorange"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("1!=2", "true"), "1%21%3D2=true"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("pound", "#"), "pound=%23"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("percent", "%"), "percent=%25"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("blank", ""), "blank="]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("fake=param&real", "is_here"), "fake%3Dparam%26real=is_here"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("is healthy", "no"), "is+healthy=no"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("2+2*2", "8"), "2%2B2%2A2=8"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("unicode", "\u00fc\u01ca\u03b9\u0107\u2205\u1d48\u00e9"), "unicode=%C3%BC%C7%8A%CE%B9%C4%87%E2%88%85%E1%B5%88%C3%A9"]), Clazz.array(java.lang.Object, -1, [C$.entry$S$S("\u00fc\u01ca\u03b9\u0107\u2205\u1d48\u00e9", "unicode"), "%C3%BC%C7%8A%CE%B9%C4%87%E2%88%85%E1%B5%88%C3%A9=unicode"])]);
});

Clazz.newMeth(C$, 'build_SingleParameter$java_util_Map_Entry$S',  function (entry, expectedBody) {
var builder=C$.newBuilder$();
builder.append$S$S(entry.getKey$(), entry.getValue$());
var body=builder.build$();
$I$(1,"assertEquals$BA$BA",[body.getBytes$(), expectedBody.getBytes$java_nio_charset_Charset($I$(2).UTF_8)]);
});

Clazz.newMeth(C$, 'asciiCharacter$',  function () {
var chars=Clazz.array(java.lang.Object, [128]);
for (var c=String.fromCharCode(0); c.$c() < chars.length ; c=String.fromCharCode(c.$c()+1)) {
chars[c.$c()]=Character.valueOf$C(c);
}
return chars;
});

Clazz.newMeth(C$, 'build_EveryCharacter_SpecialEncoded$C',  function (ch) {
var builder=C$.newBuilder$();
builder.append$S$S(String.format$S$OA("char-%02X", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(ch.$c())])), String.valueOf$C(ch));
var body=builder.build$();
var expected=String.format$S$OA("char-%02X=", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(ch.$c())]));
if ((ch >= "a" && ch <= "z" ) || (ch >= "A" && ch <= "Z" ) || (ch >= "0" && ch <= "9" ) || ch == "."   || ch == "_"  || ch == "-" ) {
expected+=ch;
} else if (ch == " ") {
expected+="+";
} else {
expected+=String.format$S$OA("%%%02X", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(ch.$c())]));
}$I$(1,"assertEquals$BA$BA",[body.getBytes$(), expected.getBytes$java_nio_charset_Charset($I$(2).UTF_8)]);
});

Clazz.newMeth(C$, 'multipleParameters$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(3,"of$O$O$O",[C$.entry$S$S("inflate", "yes"), C$.entry$S$S("registration", "completed"), C$.entry$S$S("orientation", "vertical")]), "inflate=yes&registration=completed&orientation=vertical"]), Clazz.array(java.lang.Object, -1, [$I$(3,"of$O$O$O$O",[C$.entry$S$S("fruit", "apple"), C$.entry$S$S("fruit", "blueberry"), C$.entry$S$S("vegetable", "tomato"), C$.entry$S$S("fruit", "lemon")]), "fruit=apple&fruit=blueberry&vegetable=tomato&fruit=lemon"])]);
});

Clazz.newMeth(C$, 'build_MultiParameters$java_util_List$S',  function (entries, expectedBody) {
var builder=C$.newBuilder$();
for (var entry, $entry = entries.iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
builder.append$S$S(entry.getKey$(), entry.getValue$());
}
var body=builder.build$();
$I$(1,"assertEquals$BA$BA",[body.getBytes$(), expectedBody.getBytes$java_nio_charset_Charset($I$(2).UTF_8)]);
});

Clazz.newMeth(C$, 'build_NoParameters_EmptyBody$',  function () {
var builder=C$.newBuilder$();
var body=builder.build$();
$I$(1,"assertEquals$BA$BA",[body.getBytes$(), Clazz.array(Byte.TYPE, [0])]);
});

Clazz.newMeth(C$, 'newBuilder$',  function () {
return Clazz.new_($I$(4,1));
}, 1);

Clazz.newMeth(C$, 'entry$S$S',  function (key, value) {
return Clazz.new_($I$(5,1).c$$O$O,[key, value]);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
