(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[[0,'java.net.URI','io.github.warownia1.simplehttpclient.impl.SimpleHttpRequestBuilder','org.testng.Assert','io.github.warownia1.simplehttpclient.HttpHeaders','java.util.Map','java.util.List','io.github.warownia1.simplehttpclient.impl.EmptyRequestBody','java.time.Duration']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleHttpRequestBuilderTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['EXAMPLE_URI','java.net.URI']]]

Clazz.newMeth(C$, 'createBuilder$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Clazz.new_($I$(2,1))])]);
});

Clazz.newMeth(C$, 'uri_NotProvided_Throw$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.build$();
});

Clazz.newMeth(C$, 'createValidURI$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("https://example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://example.org/")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://www.example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://example.org/path/1234")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://example.org/index.html")]), Clazz.array(java.lang.Object, -1, [$I$(1,"create$S",["http://example.org?foo=hello%20world"])]), Clazz.array(java.lang.Object, -1, [$I$(1,"create$S",["http://example.org?val1=A&val2=B"])]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://example.org#fragment")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://example.org:8080")]), Clazz.array(java.lang.Object, -1, [$I$(1,"create$S",["http://example.org:8080/path?val=A#fragm"])]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://user@exmaple.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://user:p4s5w0rd@example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://10.0.0.1")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://10.0.0.2:8000")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://[1080:0:0:0:8:800:200C:417A]")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http://[1080:0:0:0:8:800:200C:417A]:8000")])]);
});

Clazz.newMeth(C$, 'uri_ValidURI$java_net_URI',  function (uri) {
var request=Clazz.new_($I$(2,1)).uri$java_net_URI(uri).build$();
$I$(3,"assertEquals$O$O",[request.uri$(), uri]);
});

Clazz.newMeth(C$, 'createInvalidURI$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(1).create$S("example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("//example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("ftp://exmaple.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("mailto://user@example.org")]), Clazz.array(java.lang.Object, -1, [$I$(1).create$S("http:///path")])]);
});

Clazz.newMeth(C$, 'uri_InvalidURI_ThrowIAE$java_net_URI',  function (uri) {
Clazz.new_($I$(2,1)).uri$java_net_URI(uri);
});

Clazz.newMeth(C$, 'createBuilderWithURI$',  function () {
var builder=Clazz.new_($I$(2,1));
builder.uri$java_net_URI($I$(1).create$S("http://example.org"));
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [builder])]);
});

Clazz.newMeth(C$, 'header_OneValue_ValuePresent$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.header$S$S("Accept", "text/xml");
var request=builder.build$();
$I$(3,"assertEquals$O$O",[request.headers$(), $I$(4,"of$java_util_Map",[$I$(5,"of$O$O",["Accept", $I$(6).of$O("text/xml")])])]);
});

Clazz.newMeth(C$, 'header_MultipleValues_ValuesAppended$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.header$S$S("Accept", "text/xml");
builder.header$S$S("Accept", "application/json");
builder.header$S$S("Accept", "application/yaml");
var expectValues=$I$(6).of$O$O$O("text/xml", "application/json", "application/yaml");
var expectHeaders=$I$(4,"of$java_util_Map",[$I$(5).of$O$O("Accept", expectValues)]);
var request=builder.build$();
$I$(3,"assertEquals$O$O",[request.headers$(), expectHeaders]);
});

Clazz.newMeth(C$, 'header_MultiValueDifferentCase_ValuesAppended$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.header$S$S("Accept", "text/xml");
builder.header$S$S("accept", "text/css");
builder.header$S$S("ACCEPT", "text/html");
var expectValues=$I$(6).of$O$O$O("text/xml", "text/css", "text/html");
var expectHeaders=$I$(4,"of$java_util_Map",[$I$(5).of$O$O("Accept", expectValues)]);
var request=builder.build$();
$I$(3,"assertEquals$O$O",[request.headers$(), expectHeaders]);
});

Clazz.newMeth(C$, 'header_TwoHeaders_TwoValuesPresent$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.header$S$S("Accept", "text/plain");
builder.header$S$S("Content-Length", "15");
var expectedHeaders=$I$(4,"of$java_util_Map",[$I$(5,"of$O$O$O$O",["Accept", $I$(6).of$O("text/plain"), "Content-Length", $I$(6).of$O("15")])]);
var request=builder.build$();
$I$(3,"assertEquals$O$O",[request.headers$(), expectedHeaders]);
});

Clazz.newMeth(C$, 'HEAD_MethodUsed_MethodIsHEAD$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.HEAD$();
var request=builder.build$();
$I$(3,"assertEquals$S$S",[request.method$(), "HEAD"]);
});

Clazz.newMeth(C$, 'GET_MethodUsed_MethodIsGET$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.GET$();
var request=builder.build$();
$I$(3,"assertEquals$S$S",[request.method$(), "GET"]);
});

Clazz.newMeth(C$, 'POST_MethodUsed_MethodIsPOST$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.POST$io_github_warownia1_simplehttpclient_HttpRequest_Body($I$(7).getInstance$());
var request=builder.build$();
$I$(3,"assertEquals$S$S",[request.method$(), "POST"]);
});

Clazz.newMeth(C$, 'PUT_MethodUsed_MethodIsPUT$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.PUT$io_github_warownia1_simplehttpclient_HttpRequest_Body($I$(7).getInstance$());
var request=builder.build$();
$I$(3,"assertEquals$S$S",[request.method$(), "PUT"]);
});

Clazz.newMeth(C$, 'DELETE_MethodUsed_MethodIsDELETE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.DELETE$();
var request=builder.build$();
$I$(3,"assertEquals$S$S",[request.method$(), "DELETE"]);
});

Clazz.newMeth(C$, 'method_OtherMethodSet_MethodSet$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("PATCH", $I$(7).getInstance$());
var request=builder.build$();
$I$(3,"assertEquals$S$S",[request.method$(), "PATCH"]);
});

Clazz.newMeth(C$, 'POST_BodyIsNull_ThrowNPE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.POST$io_github_warownia1_simplehttpclient_HttpRequest_Body(null);
});

Clazz.newMeth(C$, 'PUT_BodyIsNull_ThrowNPE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.PUT$io_github_warownia1_simplehttpclient_HttpRequest_Body(null);
});

Clazz.newMeth(C$, 'method_NullMethod_ThrowNPE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body(null, $I$(7).getInstance$());
});

Clazz.newMeth(C$, 'method_NullBody_ThrowNPE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.method$S$io_github_warownia1_simplehttpclient_HttpRequest_Body("PATCH", null);
});

Clazz.newMeth(C$, 'timeout_PositiveTimeout_TimeoutSet$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.timeout$java_time_Duration($I$(8).ofSeconds$J(1));
var request=builder.build$();
$I$(3,"assertTrue$Z",[request.timeout$().isPresent$()]);
$I$(3,"assertEquals$J$J",[request.timeout$().get$().toMillis$(), 1000]);
});

Clazz.newMeth(C$, 'timeout_ZeroTimeout_ThrowIAE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.timeout$java_time_Duration($I$(8).ZERO);
});

Clazz.newMeth(C$, 'timeout_NegativeTimeout_ThrowIAE$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.timeout$java_time_Duration($I$(8).ofMillis$J(-10));
});

Clazz.newMeth(C$, 'timeout_NullTimeout_NotPresent$io_github_warownia1_simplehttpclient_HttpRequest_Builder',  function (builder) {
builder.timeout$java_time_Duration(null);
var request=builder.build$();
$I$(3,"assertFalse$Z",[request.timeout$().isPresent$()]);
});

C$.$static$=function(){C$.$static$=0;
C$.EXAMPLE_URI=$I$(1).create$S("http://example.org");
};
C$.$getAnn$ = function(){ return [
[['M:createBuilder','Object[][]','createBuilder$',['org.testng.annotations.DataProvider']],['name="EmptyBuilder" ']],
  [['M:createValidURI','.','createValidURI$',['org.testng.annotations.DataProvider']],['name="ValidURI" ']],
  [['M:createInvalidURI','.','createInvalidURI$',['org.testng.annotations.DataProvider']],['name="InvalidURI" ']],
  [['M:createBuilderWithURI','.','createBuilderWithURI$',['org.testng.annotations.DataProvider']],['name="BuilderWithURI" ']]]}

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
