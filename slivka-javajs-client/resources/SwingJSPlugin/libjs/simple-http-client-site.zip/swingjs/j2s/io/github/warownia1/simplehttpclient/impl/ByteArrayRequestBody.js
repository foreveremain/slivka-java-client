(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ByteArrayRequestBody", null, null, [['io.github.warownia1.simplehttpclient.HttpRequest','io.github.warownia1.simplehttpclient.HttpRequest.Body']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['length','offset'],'O',['content','byte[]']]]

Clazz.newMeth(C$, 'c$$BA',  function (content) {
C$.c$$BA$I$I.apply(this, [content, 0, content.length]);
}, 1);

Clazz.newMeth(C$, 'c$$BA$I$I',  function (content, offset, length) {
;C$.$init$.apply(this);
this.content=content;
this.offset=offset;
this.length=length;
}, 1);

Clazz.newMeth(C$, 'getBytes$',  function () {
var buffer=Clazz.array(Byte.TYPE, [this.length]);
System.arraycopy$O$I$O$I$I(this.content, this.offset, buffer, 0, this.length);
return buffer;
});

Clazz.newMeth(C$, 'contentLength$',  function () {
return this.length;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
