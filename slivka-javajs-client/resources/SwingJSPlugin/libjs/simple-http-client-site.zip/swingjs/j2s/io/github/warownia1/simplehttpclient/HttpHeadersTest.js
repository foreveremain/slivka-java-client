(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient"),I$=[[0,'java.util.Map','java.util.List','io.github.warownia1.simplehttpclient.HttpHeaders','org.testng.Assert','java.util.Set','java.util.Collections','java.util.HashMap']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HttpHeadersTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['headersMap','java.util.Map','headers','io.github.warownia1.simplehttpclient.HttpHeaders']]]

Clazz.newMeth(C$, 'setupHeaders$',  function () {
this.headersMap=$I$(1,"of$O$O$O$O$O$O$O$O",["Content-Length", $I$(2).of$O("10"), "Authorization", $I$(2).of$O("DE4D83EF"), "Accept", $I$(2).of$O$O("application/json", "text/xml"), "Accept-Encoding", $I$(2).of$()]);
this.headers=$I$(3).of$java_util_Map(this.headersMap);
});

Clazz.newMeth(C$, 'map_AllHeaders_OnlyNonEmptyPresent$',  function () {
$I$(4,"assertEquals$java_util_Set$java_util_Set",[this.headers.map$().keySet$(), $I$(5).of$O$O$O("Content-Length", "Authorization", "Accept")]);
});

Clazz.newMeth(C$, 'map_SimpleValue_EqualOriginal$',  function () {
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[this.headers.map$().get$O("Content-Length"), $I$(2).of$O("10")]);
});

Clazz.newMeth(C$, 'map_MultiValue_AllEqualOriginal$',  function () {
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[this.headers.map$().get$O("Accept"), $I$(2).of$O$O("application/json", "text/xml")]);
});

Clazz.newMeth(C$, 'firstValue_OneValuePresent_GetValue$',  function () {
var contentLength=this.headers.firstValue$S("Content-Length");
$I$(4,"assertTrue$Z",[contentLength.isPresent$()]);
$I$(4,"assertEquals$S$S",[contentLength.get$(), "10"]);
});

Clazz.newMeth(C$, 'allValues_OneValue_ListsEqual$',  function () {
var contentLength=this.headers.allValues$S("Content-Length");
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[contentLength, $I$(2).of$O("10")]);
});

Clazz.newMeth(C$, 'firstValue_MultipleValuesPresent_GetFirstValue$',  function () {
var accept=this.headers.firstValue$S("Accept");
$I$(4,"assertTrue$Z",[accept.isPresent$()]);
$I$(4,"assertEquals$S$S",[accept.get$(), "application/json"]);
});

Clazz.newMeth(C$, 'allValues_MultipleValues_ListsEqual$',  function () {
var accept=this.headers.allValues$S("Accept");
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[accept, $I$(2).of$O$O("application/json", "text/xml")]);
});

Clazz.newMeth(C$, 'firstValue_MissingKey_ValueNotPresent$',  function () {
var connection=this.headers.firstValue$S("Connection");
$I$(4,"assertFalse$Z",[connection.isPresent$()]);
});

Clazz.newMeth(C$, 'allValues_MissingKey_EmptyList$',  function () {
var connection=this.headers.allValues$S("Connection");
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[connection, $I$(2).of$()]);
});

Clazz.newMeth(C$, 'createValueTrimmingHeaders$',  function () {
var values=$I$(2,"of$OA",[Clazz.array(String, -1, ["gzip", " gzip", "gzip ", "  gzip", "gzip  ", " gzip ", "\tgzip", "gzip\t", "\tgzip\t", " \tgzip", "gzip \t", "gzip\t ", "\rgzip", "gzip\r", "\ngzip", "gzip\n", "gzip\r\n"])]);
var args=Clazz.array(java.lang.Object, [values.size$(), null]);
var i=0;
for (var value, $value = values.iterator$(); $value.hasNext$()&&((value=($value.next$())),1);) {
args[i++]=Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["Accept-Encoding", $I$(2).of$O(value)])]);
}
return args;
});

Clazz.newMeth(C$, 'firstValue_ValueContainsSpaces_ValueTrimmed$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertTrue$Z",[headers.firstValue$S("Accept-Encoding").isPresent$()]);
$I$(4,"assertEquals$S$S",[headers.firstValue$S("Accept-Encoding").get$(), "gzip"]);
});

Clazz.newMeth(C$, 'allValues_ValueContainsSpaces_ValueTrimmed$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept-Encoding"), $I$(2).of$O("gzip")]);
});

Clazz.newMeth(C$, 'map_ValueContainsSpaces_ValueTrimmed$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.map$().get$O("Accept-Encoding"), $I$(2).of$O("gzip")]);
});

Clazz.newMeth(C$, 'createKeyTrimmingHeaders$',  function () {
var keys=$I$(2,"of$OA",[Clazz.array(String, -1, ["Accept", " Accept", "Accept ", "  Accept", "Accept  ", "\tAccept", "Accept\t", "\rAccept", "Accept\r", "Accept\n", "Accept\n", "Accept\r\n", "Accept \t"])]);
var args=Clazz.array(java.lang.Object, [keys.size$(), null]);
var i=0;
for (var key, $key = keys.iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
args[i++]=Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",[key, $I$(2).of$O("text/plain")])]);
}
return args;
});

Clazz.newMeth(C$, 'firstValue_KeyContainsSpace_KeyTrimmed$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertTrue$Z",[headers.firstValue$S("Accept").isPresent$()]);
$I$(4,"assertEquals$S$S",[headers.firstValue$S("Accept").get$(), "text/plain"]);
});

Clazz.newMeth(C$, 'allValues_KeyContainsSpace_KeyTrimmed$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(2).of$O("text/plain")]);
});

Clazz.newMeth(C$, 'map_KeyContainsSpace_KeyTrimmed$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertTrue$Z",[headers.map$().containsKey$O("Accept")]);
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.map$().get$O("Accept"), $I$(2).of$O("text/plain")]);
});

Clazz.newMeth(C$, 'createCaseInsensitiveHeaders$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["Content-Length", $I$(2).of$O("25")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["content-length", $I$(2).of$O("25")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["CONTENT-LENGTH", $I$(2).of$O("25")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["ContEnt-LenGtH", $I$(2).of$O("25")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["conTent-lENGTH", $I$(2).of$O("25")])])]);
});

Clazz.newMeth(C$, 'firstValue_HeaderNameIgnoresCase$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
for (var key, $key = $I$(2).of$O$O$O$O("Content-Length", "content-length", "CONTENT-LENGTH", "CoNtENt-LengtH").iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
$I$(4,"assertTrue$Z",[headers.firstValue$S(key).isPresent$()]);
$I$(4,"assertEquals$S$S",[headers.firstValue$S(key).get$(), "25"]);
}
});

Clazz.newMeth(C$, 'allValues_HeaderNameIgnoresCase$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
for (var key, $key = $I$(2).of$O$O$O$O("Content-Length", "content-length", "CONTENT-LENGTH", "CoNtENt-LengtH").iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S(key), $I$(2).of$O("25")]);
}
});

Clazz.newMeth(C$, 'map_MapKeysIgnoreCase$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
for (var key, $key = $I$(2).of$O$O$O$O("Content-Length", "content-length", "CONTENT-LENGTH", "CoNtENt-LengtH").iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
$I$(4,"assertTrue$Z",[headers.map$().containsKey$O(key)]);
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.map$().get$O(key), $I$(2).of$O("25")]);
}
});

Clazz.newMeth(C$, 'createNoValueHeaders$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["Accept", $I$(2).of$()])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["Accept", $I$(6).emptyList$()])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["Accept", $I$(2).of$(), "Encoding", $I$(2).of$()])])]);
});

Clazz.newMeth(C$, 'firstValue_NoValues_ValueNotPresent$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertFalse$Z",[headers.firstValue$S("Accept").isPresent$()]);
});

Clazz.newMeth(C$, 'allValues_NoValues_EmptyList$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertEquals$java_util_Collection$java_util_Collection",[headers.allValues$S("Accept"), $I$(2).of$()]);
});

Clazz.newMeth(C$, 'map_NoValues_EmptyMap$java_util_Map',  function (map) {
var headers=$I$(3).of$java_util_Map(map);
$I$(4,"assertFalse$Z",[headers.map$().containsKey$O("Accept")]);
$I$(4,"assertEquals$I$I",[headers.map$().size$(), 0]);
$I$(4,"assertNull$O",[headers.map$().get$O("Accept")]);
});

Clazz.newMeth(C$, 'of_NullMap_Throw$',  function () {
$I$(3).of$java_util_Map(null);
});

Clazz.newMeth(C$, 'of_NullKey_Throw$',  function () {
var map=Clazz.new_($I$(7,1));
map.put$O$O(null, $I$(2).of$O("value"));
$I$(3).of$java_util_Map(map);
});

Clazz.newMeth(C$, 'of_NullValue_Throw$',  function () {
var map=Clazz.new_($I$(7,1));
map.put$O$O("Content-Length", null);
$I$(3).of$java_util_Map(map);
});

Clazz.newMeth(C$, 'createEmptyNameHeaders$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["", $I$(2).of$O("V")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",[" ", $I$(2).of$O("V")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["  ", $I$(2).of$O("V")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["\t", $I$(2).of$O("V")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["\t\t", $I$(2).of$O("V")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",[" \t", $I$(2).of$O("V")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O",["\t ", $I$(2).of$O("V")])])]);
});

Clazz.newMeth(C$, 'of_EmptyKey_ThrowIAE$java_util_Map',  function (map) {
$I$(3).of$java_util_Map(map);
});

Clazz.newMeth(C$, 'createDuplicateNamesHeaders$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["Connection", $I$(2).of$O("close"), "connection", $I$(2).of$O("keep-alive")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["Connection", $I$(2).of$(), "connection", $I$(2).of$()])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["Connection", $I$(2).of$O("close"), "connection", $I$(2).of$()])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["Connection", $I$(2).of$(), "connection", $I$(2).of$O("keep-alive")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O$O$O",["Connection", $I$(2).of$O("close"), "Accept-Encoding", $I$(2).of$O("deflate"), "accept-encoding", $I$(2).of$O("deflate")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["Accept-Encoding", $I$(2).of$O("deflate"), "Accept-Encoding ", $I$(2).of$O("gzip")])]), Clazz.array(java.lang.Object, -1, [$I$(1,"of$O$O$O$O",["\nAccept-Encoding", $I$(2).of$O("deflate"), "Accept-Encoding\t", $I$(2).of$O("gzip")])])]);
});

Clazz.newMeth(C$, 'of_DuplicateKey_Throw$java_util_Map',  function (map) {
$I$(3).of$java_util_Map(map);
});

Clazz.newMeth(C$, 'equals_EmptyHeaders_Equal$',  function () {
var headers1=$I$(3,"of$java_util_Map",[$I$(1).of$()]);
var headers2=$I$(3,"of$java_util_Map",[$I$(1).of$()]);
$I$(4).assertEquals$O$O(headers1, headers2);
});

Clazz.newMeth(C$, 'equals_NonHeadersType_NotEqual$',  function () {
var headers=$I$(3,"of$java_util_Map",[$I$(1).of$()]);
var map=$I$(1).of$();
$I$(4).assertNotEquals$O$O(headers, map);
});

Clazz.newMeth(C$, 'equals_SameKeysAndValues_Equal$',  function () {
var headers1=$I$(3,"of$java_util_Map",[$I$(1,"of$O$O$O$O",["Accept", $I$(2).of$O$O("text/plain", "text/html"), "Content-Length", $I$(2).of$O("25")])]);
var headers2=$I$(3,"of$java_util_Map",[$I$(1,"of$O$O$O$O",["Accept", $I$(2).of$O$O("text/plain", "text/html"), "Content-Length", $I$(2).of$O("25")])]);
$I$(4).assertEquals$O$O(headers1, headers2);
});

Clazz.newMeth(C$, 'equals_CaseInsensitiveNames_AllEqual$',  function () {
var maps=$I$(2,"of$O$O$O$O$O",[$I$(1,"of$O$O",["Content-Length", $I$(2).of$O("25")]), $I$(1,"of$O$O",["content-length", $I$(2).of$O("25")]), $I$(1,"of$O$O",["CONTENT-LENGTH", $I$(2).of$O("25")]), $I$(1,"of$O$O",["ContEnt-LenGtH", $I$(2).of$O("25")]), $I$(1,"of$O$O",["conTent-lENGTH", $I$(2).of$O("25")])]);
for (var map1, $map1 = maps.iterator$(); $map1.hasNext$()&&((map1=($map1.next$())),1);) {
var headers1=$I$(3).of$java_util_Map(map1);
for (var map2, $map2 = maps.iterator$(); $map2.hasNext$()&&((map2=($map2.next$())),1);) {
var headers2=$I$(3).of$java_util_Map(map2);
$I$(4).assertEquals$O$O(headers1, headers2);
}
}
});

Clazz.newMeth(C$, 'equals_SameKeysDifferentValues_NotEqual$',  function () {
var headers1=$I$(3,"of$java_util_Map",[$I$(1,"of$O$O$O$O",["Accept", $I$(2).of$O$O("text/plain", "text/html"), "Content-Length", $I$(2).of$O("25")])]);
var headers2=$I$(3,"of$java_util_Map",[$I$(1,"of$O$O$O$O",["Accept", $I$(2).of$O$O("text/plain", "text/css"), "Content-Length", $I$(2).of$O("25")])]);
$I$(4).assertNotEquals$O$O(headers1, headers2);
});
C$.$getAnn$ = function(){ return [
[['M:createValueTrimmingHeaders','Object[][]','createValueTrimmingHeaders$',['org.testng.annotations.DataProvider']],['name="ValueTrimming" ']],
  [['M:createKeyTrimmingHeaders','.','createKeyTrimmingHeaders$',['org.testng.annotations.DataProvider']],['name="KeyTrimming" ']],
  [['M:createCaseInsensitiveHeaders','.','createCaseInsensitiveHeaders$',['org.testng.annotations.DataProvider']],['name="CaseInsensitiveHeaders" ']],
  [['M:createNoValueHeaders','.','createNoValueHeaders$',['org.testng.annotations.DataProvider']],['name="EmptyListValue" ']],
  [['M:createEmptyNameHeaders','.','createEmptyNameHeaders$',['org.testng.annotations.DataProvider']],['name="EmptyName" ']],
  [['M:createDuplicateNamesHeaders','.','createDuplicateNamesHeaders$',['org.testng.annotations.DataProvider']],['name="DuplicateNames" ']]]}

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
