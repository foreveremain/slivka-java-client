(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient.impl"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleHttpResponse", null, null, 'io.github.warownia1.simplehttpclient.HttpResponse');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['statusCode'],'O',['request','io.github.warownia1.simplehttpclient.HttpRequest','headers','io.github.warownia1.simplehttpclient.HttpHeaders','body','<T>','uri','java.net.URI']]]

Clazz.newMeth(C$, 'c$$I$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpHeaders$O$java_net_URI',  function (statusCode, request, headers, body, uri) {
;C$.$init$.apply(this);
this.statusCode=statusCode;
this.request=request;
this.headers=headers;
this.body=body;
this.uri=uri;
}, 1);

Clazz.newMeth(C$, 'statusCode$',  function () {
return this.statusCode;
});

Clazz.newMeth(C$, 'request$',  function () {
return this.request;
});

Clazz.newMeth(C$, 'headers$',  function () {
return this.headers;
});

Clazz.newMeth(C$, 'body$',  function () {
return this.body;
});

Clazz.newMeth(C$, 'uri$',  function () {
return this.uri;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
