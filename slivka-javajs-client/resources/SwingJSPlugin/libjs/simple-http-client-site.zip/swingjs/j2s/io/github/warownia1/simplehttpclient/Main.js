(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient"),I$=[[0,'io.github.warownia1.simplehttpclient.impl.ByteArrayRequestBody','io.github.warownia1.simplehttpclient.impl.SimpleHttpRequestBuilder','java.net.URI','io.github.warownia1.simplehttpclient.impl.JQueryHttpClient',['io.github.warownia1.simplehttpclient.HttpResponse','.BodyHandlers']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Main");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var content="Hello world";
var body=Clazz.new_([content.getBytes$()],$I$(1,1).c$$BA);
var request=Clazz.new_($I$(2,1)).uri$java_net_URI($I$(3).create$S("http://localhost:5000")).header$S$S("Foo", "foo").header$S$S("Foo", "bar").header$S$S("Baz", "baz").GET$().build$();
var client=Clazz.new_($I$(4,1));
var response=client.send$io_github_warownia1_simplehttpclient_HttpRequest$io_github_warownia1_simplehttpclient_HttpResponse_BodyHandler(request, $I$(5).ofString$());
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
