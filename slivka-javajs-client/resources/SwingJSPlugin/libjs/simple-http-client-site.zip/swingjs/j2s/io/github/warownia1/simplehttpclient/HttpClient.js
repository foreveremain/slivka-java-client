(function(){var P$=Clazz.newPackage("io.github.warownia1.simplehttpclient"),I$=[[0,'io.github.warownia1.simplehttpclient.impl.SimpleHttpClient','io.github.warownia1.simplehttpclient.impl.JQueryHttpClient']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "HttpClient", function(){
});
C$.$classes$=[['Version',25]];

Clazz.newMeth(C$, 'newHttpClient$',  function () {
if (false &&true) return Clazz.new_($I$(1,1));
 else return Clazz.new_($I$(2,1));
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.HttpClient, "Version", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "HTTP_1_1", 0, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
})();
;Clazz.setTVer('3.3.1-v1');//Created 2023-10-13 14:49:51 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
